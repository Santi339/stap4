class Company:

    def __init__(self, rank, company, ticker, sector, country):
        self.rank = rank
        self.company = company
        self.ticker = ticker
        self.sector = sector
        self.country = country