# group2_step4
Members of Group 2 worked on their individual parts for the code in order to built a working system that behaved as so:
Meanwhile parsing, interacting, and studying the csv file and its' contents in question, this code has the capabilities to search from a csv file, add, and delete to and from an array which can be saved into a new csv file. 

Meeting link for 9/20/24
https://csustan.zoom.us/rec/share/ZAdnh525RLebrbeJ1WZPYO6gGkV7eSZOaKUtaM0D93aSqiflIoYCEU_81GrBf3Zn.y3yAh5goQEki2iKA 
Meeting link for 9/23/24
https://csustan.zoom.us/rec/share/zId_LkisrpnnpVwmMYCdJJWMiawAylDD0peBKM-X6Sj9JOVO0f86S7QpR9OO0cE.WdeTl6V8Z1aCkkDk?startTime=1727117992000 
Meeting link for 9/27/24
https://csustan.zoom.us/rec/share/W1CQQluGisPdpWKJu0w6wzS5SccYgL9aa6QoRk2sAP4T2Z8HRZk-nI-66lK6Ykhq.Wq2ZVAw5PjM5bUyB?startTime=1727463634000 
Meeting link for 9/30/24
https://csustan.zoom.us/rec/share/ksgTHgrn4C1fjs43xv0IsJmnbe7oH2l-FlxjJTUHwXJo7b2UfdqoPSRLIsOwnLE._yIfT-6t167HSNrW?startTime=1727722814000
